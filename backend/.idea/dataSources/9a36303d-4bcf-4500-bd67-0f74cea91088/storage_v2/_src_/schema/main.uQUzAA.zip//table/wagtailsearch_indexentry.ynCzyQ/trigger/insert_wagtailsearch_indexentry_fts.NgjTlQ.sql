CREATE TRIGGER insert_wagtailsearch_indexentry_fts AFTER INSERT ON wagtailsearch_indexentry BEGIN INSERT INTO wagtailsearch_indexentry_fts(title, body, autocomplete, rowid) VALUES (NEW.title, NEW.body, NEW.autocomplete, NEW.id); END;

